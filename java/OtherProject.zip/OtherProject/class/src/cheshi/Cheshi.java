package cheshi;

import java.sql.*;

import handle.HandleInsertData;
import handle.HandleLogin;
import model.Login;
import model.Register;

public class Cheshi {
	public static void main(String[] args) {
		Register user = new Register();
		user.setID("9527");
		user.setPassword("123456");
		user.setBirth("1999-12-10");
		HandleInsertData handleRegister = new HandleInsertData();
		handleRegister.writeRegisterModel(user);
		Login login = new Login();
		login.setID("9527");
		login.setPassword("123456");
		HandleLogin handleLogin = new HandleLogin();
		login = handleLogin.queryVerify(login);
		if (login.getLoginSuccess() == true) {
			System.out.println("��¼�ɹ��ˣ�");
		}
	}
}