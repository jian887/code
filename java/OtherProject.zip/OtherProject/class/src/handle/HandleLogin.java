package handle;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

import class11_1.Hua_Rong_Road;
import model.Login;

public class HandleLogin {
	Connection con;
	PreparedStatement preSql;
	ResultSet rs;

	public HandleLogin() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (Exception e) {
		}
		String uri = "jdbc:mysql://localhost:3306/user";
		try {
			con = DriverManager.getConnection(uri, "root", "123456");
		} catch (SQLException e) {
		}
	}

	public Login queryVerify(Login loginModel) {
		String id = loginModel.getID();
		String pw = loginModel.getPassword();
		String sqlStr = "select id,password from register where " + "id = ? and password = ?";
		try {
			preSql = con.prepareStatement(sqlStr);
			preSql.setString(1, id);
			preSql.setString(2, pw);
			rs = preSql.executeQuery();
			if (rs.next() == true) {
				loginModel.setLoginSuccess(true);
				JOptionPane.showMessageDialog(null, "��¼�ɹ�", "��ϲ", JOptionPane.WARNING_MESSAGE);
				new Hua_Rong_Road();
			} else {
				loginModel.setLoginSuccess(false);
				JOptionPane.showMessageDialog(null, "��¼ʧ��", "��¼ʧ�ܣ����µ�¼", JOptionPane.WARNING_MESSAGE);
			}
			con.close();
		} catch (SQLException e) {
		}
		return loginModel;
	}
}
