package handle;

import java.sql.*;
import javax.swing.JOptionPane;

import model.Register;

public class HandleInsertData {
	Connection con;
	PreparedStatement preSql;

	public HandleInsertData() {
		try {
			Class.forName("com.mysql.jdbc.Driver");// ����JDBC-MySQL����
		} catch (Exception e) {
		}
		String uri = "jdbc:mysql://localhost:3306/user";
		try {
			con = DriverManager.getConnection(uri, "root", "123456"); // ���Ӵ���
		} catch (SQLException e) {
		}

	}

	public void writeRegisterModel(Register register) {
		String yonghu1 = "insert into register values(?,?,?)";
		int ok = 0;
		try {
			preSql = con.prepareStatement(yonghu1);
			preSql.setString(1, register.getID());
			preSql.setString(2, register.getPassword());
			preSql.setString(3, register.getBirth());
			ok = preSql.executeUpdate();
			con.close();
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "id�����ظ�", "����", JOptionPane.WARNING_MESSAGE);
		}
		if (ok != 0) {
			JOptionPane.showMessageDialog(null, "ע��ɹ�", "��ϲ", JOptionPane.WARNING_MESSAGE);
		}
	}
}
