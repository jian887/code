import cn.jerryshell.dao.SecurityQuestionDAO;
import cn.jerryshell.dao.impl.SecurityQuestionDAOImpl;
import cn.jerryshell.dao.impl.UserDAOImpl;
import cn.jerryshell.entity.SecurityQuestion;
import cn.jerryshell.entity.User;

public class SecurityQuestionDAOImplTest {

	public static User user = new UserDAOImpl().getUserById(1);
	public static SecurityQuestionDAO securityQuestionDAO = new SecurityQuestionDAOImpl();

	public static void main(String[] args) {
		// createSecurityQuestion();
		// getSecurityQuestionByUserId();
		updateSecurityQuestion();
	}

	public static void createSecurityQuestion() {
		SecurityQuestion securityQuestion = new SecurityQuestion();
		securityQuestion.setUserId(user.getId());
		securityQuestion.setQuestion("test");
		securityQuestion.setAnswer("jerry");
		securityQuestionDAO.createSecurityQuestion(securityQuestion);
	}

	public static void getSecurityQuestionByUserId() {
		SecurityQuestion securityQuestion = securityQuestionDAO.getSecurityQuestionByUserId(user.getId());
		System.out.println(securityQuestion);
	}

	public static void updateSecurityQuestion() {
		SecurityQuestion securityQuestion = securityQuestionDAO.getSecurityQuestionByUserId(user.getId());
		securityQuestion.setAnswer("kkk");
		securityQuestionDAO.updateSecurityQuestion(securityQuestion);
		System.out.println(securityQuestion);
	}

}
