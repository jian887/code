package cn.jerryshell.service;

import cn.jerryshell.entity.SecurityQuestion;

public interface SecurityQuestionService {

	/**
	 * 创建密保问题
	 * 
	 * @param userId
	 * @param question
	 * @param answer
	 */
	public void createSecurityQuestion(int userId, String question, String answer);

	/**
	 * 更新密保问题
	 * 
	 * @param id
	 * @param userId
	 * @param question
	 * @param answer
	 */
	public void updateSecurityQuestion(int id, int userId, String question, String answer);

	/**
	 * 根据 userId 获得密保问题
	 * 
	 * @param userId
	 * @return
	 */
	public SecurityQuestion getSecurityQuestionByUserId(int userId);
}
