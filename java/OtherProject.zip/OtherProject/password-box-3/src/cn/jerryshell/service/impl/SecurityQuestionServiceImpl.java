package cn.jerryshell.service.impl;

import cn.jerryshell.dao.SecurityQuestionDAO;
import cn.jerryshell.dao.impl.SecurityQuestionDAOImpl;
import cn.jerryshell.entity.SecurityQuestion;
import cn.jerryshell.service.SecurityQuestionService;

public class SecurityQuestionServiceImpl implements SecurityQuestionService {

	private SecurityQuestionDAO securityQuestionDAO = new SecurityQuestionDAOImpl();

	@Override
	public void createSecurityQuestion(int userId, String question, String answer) {
		SecurityQuestion securityQuestion = new SecurityQuestion();
		securityQuestion.setUserId(userId);
		securityQuestion.setQuestion(question);
		securityQuestion.setAnswer(answer);
		securityQuestionDAO.createSecurityQuestion(securityQuestion);
	}

	@Override
	public void updateSecurityQuestion(int id, int userId, String question, String answer) {
		SecurityQuestion securityQuestion = new SecurityQuestion();
		securityQuestion.setId(userId);
		securityQuestion.setUserId(userId);
		securityQuestion.setQuestion(question);
		securityQuestion.setAnswer(answer);
		securityQuestionDAO.updateSecurityQuestion(securityQuestion);
	}

	@Override
	public SecurityQuestion getSecurityQuestionByUserId(int userId) {
		SecurityQuestion securityQuestion = securityQuestionDAO.getSecurityQuestionByUserId(userId);
		return securityQuestion;
	}

}
