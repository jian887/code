package cn.jerryshell.service;

import cn.jerryshell.entity.User;

public interface UserService {

	/**
	 * 注册用户
	 * 
	 * @param username
	 * @param password
	 * @param email
	 * @return
	 */
	public User register(String username, String password, String email);

	/**
	 * 删除用户
	 * 
	 * @param id
	 */
	public void deleteUser(int id);

	/**
	 * 更新用户
	 * 
	 * @param id
	 * @param username
	 * @param password
	 * @param email
	 * @return
	 */
	public User updateUser(int id, String username, String password, String email);

	/**
	 * 登录
	 * 
	 * @param username
	 * @param password
	 * @return
	 */
	public User login(String username, String password);

	/**
	 * 根据 id 查找用户
	 * 
	 * @param id
	 * @return
	 */
	public User findUserById(int id);

	/**
	 * 根据用户名查找用户
	 * 
	 * @param username
	 * @return
	 */
	public User findUserByUsername(String username);
}
