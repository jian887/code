package cn.jerryshell.util;

public class ControllerUtil {

	public static boolean isEmpty(String... strs) {
		for (int i = 0, len = strs.length; i < len; i++) {
			String str = strs[i];
			if (str == null || str.trim().isEmpty()) {
				return true;
			}
		}
		return false;
	}
}
