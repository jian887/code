package cn.jerryshell.controller;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.jerryshell.entity.Account;
import cn.jerryshell.entity.SecurityQuestion;
import cn.jerryshell.entity.User;
import cn.jerryshell.service.AccountService;
import cn.jerryshell.service.LoginHistoryService;
import cn.jerryshell.service.SecurityQuestionService;
import cn.jerryshell.service.impl.AccountServiceImpl;
import cn.jerryshell.service.impl.LoginHistoryServiceImpl;
import cn.jerryshell.service.impl.SecurityQuestionServiceImpl;

@WebServlet("/account")
public class AccountController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private AccountService accountService = new AccountServiceImpl();
	private LoginHistoryService loginHistoryService = new LoginHistoryServiceImpl();
	private SecurityQuestionService securityQuestionService = new SecurityQuestionServiceImpl();

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action");
		if ("list".equals(action)) {
			list(request, response);
		} else if ("addAccount".equals(action)) {
			addAccount(request, response);
		} else if ("deleteAccount".equals(action)) {
			deleteAccount(request, response);
		} else if ("updateAccountUI".equals(action)) {
			updateAccountUI(request, response);
		} else if ("updateAccount".equals(action)) {
			updateAccount(request, response);
		} else {
			String message = "未知操作";
			request.setAttribute("message", message);
			request.getRequestDispatcher("message.jsp").forward(request, response);
		}
	}

	@SuppressWarnings("deprecation")
	private void list(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		User user = (User) request.getSession().getAttribute("user");

		List<Account> accountList;
		accountList = accountService.getAccountListByUserId(user.getId());

		int loginTotal = loginHistoryService.getLoginTotalNumberByUserId(user.getId());
		String lastLoginDate = "无";
		List<Date> dateList = loginHistoryService.getRecently2LoginDateTimeByUserId(user.getId());
		if (dateList.size() == 2) {
			lastLoginDate = dateList.get(1).toLocaleString();
		}

		SecurityQuestion securityQuestion = securityQuestionService.getSecurityQuestionByUserId(user.getId());
		boolean isSecurity = (securityQuestion != null);

		request.setAttribute("accountList", accountList);
		request.setAttribute("loginTotal", loginTotal);
		request.setAttribute("lastLoginDate", lastLoginDate);
		request.setAttribute("isSecurity", isSecurity);
		request.getRequestDispatcher("account/accountList.jsp").forward(request, response);
	}

	private void addAccount(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		User user = (User) request.getSession().getAttribute("user");
		String password = request.getParameter("password");
		String info = request.getParameter("info");
		accountService.addAccount(user.getId(), password, info);
		response.sendRedirect(request.getContextPath() + "/account?action=list");
	}

	private void deleteAccount(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String idStr = request.getParameter("id");
		int id = Integer.parseInt(idStr);
		accountService.deleteAccount(id);
		response.sendRedirect(request.getContextPath() + "/account?action=list");
	}

	private void updateAccountUI(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String idStr = request.getParameter("id");
		int id = Integer.parseInt(idStr);
		Account account = accountService.getAccountById(id);
		request.setAttribute("account", account);
		request.getRequestDispatcher("account/updateAccount.jsp").forward(request, response);
	}

	private void updateAccount(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		User user = (User) request.getSession().getAttribute("user");
		String idStr = request.getParameter("id");
		int id = Integer.parseInt(idStr);
		String password = request.getParameter("password");
		String info = request.getParameter("info");
		accountService.updateAccount(id, user.getId(), password, info);
		response.sendRedirect(request.getContextPath() + "/account?action=list");
	}

}
