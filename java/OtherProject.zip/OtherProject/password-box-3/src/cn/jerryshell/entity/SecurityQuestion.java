package cn.jerryshell.entity;

public class SecurityQuestion {

	private int id;
	private int userId;
	private String question;
	private String answer;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	@Override
	public String toString() {
		return "SecurityQuestion [id=" + id + ", userId=" + userId + ", question=" + question + ", answer=" + answer
				+ "]";
	}

}
