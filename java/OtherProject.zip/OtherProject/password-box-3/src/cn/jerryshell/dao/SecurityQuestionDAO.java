package cn.jerryshell.dao;

import cn.jerryshell.entity.SecurityQuestion;

public interface SecurityQuestionDAO {

	/**
	 * 创建密保问题
	 * 
	 * @param securityQuestion
	 */
	public void createSecurityQuestion(SecurityQuestion securityQuestion);

	/**
	 * 更新密保问题
	 * 
	 * @param securityQuestion
	 */
	public void updateSecurityQuestion(SecurityQuestion securityQuestion);

	/**
	 * 根据 userId 获得密保问题
	 * 
	 * @param userId
	 * @return
	 */
	public SecurityQuestion getSecurityQuestionByUserId(int userId);
}
