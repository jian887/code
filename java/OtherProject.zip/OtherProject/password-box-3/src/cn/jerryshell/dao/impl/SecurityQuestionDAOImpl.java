package cn.jerryshell.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import cn.jerryshell.dao.SecurityQuestionDAO;
import cn.jerryshell.entity.SecurityQuestion;
import cn.jerryshell.util.DBUtil;

public class SecurityQuestionDAOImpl implements SecurityQuestionDAO {

	@Override
	public void createSecurityQuestion(SecurityQuestion securityQuestion) {
		String sql = "insert into security_question(user_id, question, answer) value(?,?,?)";
		Connection connection = DBUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		try {
			statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			statement.setObject(1, securityQuestion.getUserId());
			statement.setObject(2, securityQuestion.getQuestion());
			statement.setObject(3, securityQuestion.getAnswer());

			statement.executeUpdate();
			resultSet = statement.getGeneratedKeys();
			if (resultSet.next()) {
				int id = resultSet.getInt(1);
				securityQuestion.setId(id);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(connection, statement, resultSet);
		}
	}

	@Override
	public void updateSecurityQuestion(SecurityQuestion securityQuestion) {
		String sql = "update security_question set question=?, answer=? where id=?";
		Connection connection = DBUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		try {
			statement = connection.prepareStatement(sql);
			statement.setObject(1, securityQuestion.getQuestion());
			statement.setObject(2, securityQuestion.getAnswer());
			statement.setObject(3, securityQuestion.getId());

			statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(connection, statement, resultSet);
		}
	}

	@Override
	public SecurityQuestion getSecurityQuestionByUserId(int userId) {
		SecurityQuestion securityQuestion = null;
		String sql = "select id, question, answer from security_question where user_id=?";
		Connection connection = DBUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		try {
			statement = connection.prepareStatement(sql);
			statement.setObject(1, userId);

			resultSet = statement.executeQuery();
			if (resultSet.next()) {
				int id = resultSet.getInt("id");
				String question = resultSet.getString("question");
				String answer = resultSet.getString("answer");

				securityQuestion = new SecurityQuestion();
				securityQuestion.setId(id);
				securityQuestion.setUserId(userId);
				securityQuestion.setQuestion(question);
				securityQuestion.setAnswer(answer);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(connection, statement, resultSet);
		}
		return securityQuestion;
	}

}
