package cn.jerryshell.dao;

import java.util.List;

import cn.jerryshell.entity.User;

public interface UserDAO {

	/**
	 * 添加用户
	 * 
	 * @param user
	 */
	public void addUser(User user);

	/**
	 * 更新用户
	 * 
	 * @param user
	 */
	public void updateUser(User user);

	/**
	 * 删除用户
	 * 
	 * @param id
	 */
	public void deleteUser(int id);

	/**
	 * 通过 id 查找用户
	 * 
	 * @param id
	 * @return
	 */
	public User getUserById(int id);

	/**
	 * 通过用户名查找用户
	 * 
	 * @param username
	 * @return
	 */
	public User getUserByUsername(String username);

	/**
	 * 通过用户名和密码查找用户
	 * 
	 * @param username
	 * @param password
	 * @return
	 */
	public User getUserByUsernameAndPassword(String username, String password);

	/**
	 * 获取全部用户
	 * 
	 * @return
	 */
	public List<User> list();

	/**
	 * 从第 start 位置开始，获取指定 number 数量的用户
	 * 
	 * @param start
	 * @param number
	 * @return
	 */
	public List<User> list(int start, int number);

	/**
	 * 获取用户总数
	 * 
	 * @return
	 */
	public int total();
}
