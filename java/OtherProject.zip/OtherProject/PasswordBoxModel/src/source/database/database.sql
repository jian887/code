create database password;

--1.原子性  2.唯一性  3.冗余性
create table person
(
	personId int primary key auto_increment,
	personName varchar(50),
	personPaswword varchar(50),
	personRegistTime dateTime
);

create table password
(
	passwordId int primary key auto_increment,
	passwordCode varchar(50),
	passwordText varchar(50),
	passwordName varchar(50),
	personId int ,
	foreign key(personId) references person(personId) on delete cascade on update cascade
);


