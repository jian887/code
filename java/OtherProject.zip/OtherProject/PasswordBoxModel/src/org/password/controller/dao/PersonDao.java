package org.password.controller.dao;

import org.password.model.Person;

public interface PersonDao {

	/**
	 * 用户注册
	 * @param person （personName , personPassword）
	 * @return
	 */
	public boolean personRegist(Person person);
	
	/**
	 * 用户登录
	 * @param person (personName,personPassword)
	 * @return
	 */
	public Person personLogin(Person person);
}
