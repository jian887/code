package org.password.controller.implement;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import org.password.controller.dao.PersonDao;
import org.password.model.Person;
import org.password.utils.SqlExecute;

public class PersonDaoImplement extends SqlExecute implements PersonDao{

	
	@Override
	public boolean personRegist(Person person) {
		String sql = "insert into person (personName,personPassword,personRegistTime) value (?,?,now())";
		String personName = person.getPersonName();
		String personPassword = person.getPersonPassword();
		Object[] objects = {personName,personPassword};
		boolean b  = sqlExecuteUpdate(sql, objects);
		return b;
	}

	
	@Override
	public Person personLogin(Person person) {
		String sql = "select * from person where personName = ? and personPassword = ?";
		String personName = person.getPersonName();
		String personPassword = person.getPersonPassword();
		Object[] objects = {personName,personPassword};
		ResultSet rs = sqlExecutteQuery(sql, objects);
		try {
			if(rs.next()) {
				int personId = rs.getInt("personId");
				Date personRegistTime = rs.getDate("personRegistTime");
				person = new Person(personId, personName, personPassword, personRegistTime);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			close(rs);
		}
		return person;
	}

	
}
