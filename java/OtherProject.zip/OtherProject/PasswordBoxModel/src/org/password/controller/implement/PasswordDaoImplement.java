package org.password.controller.implement;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.password.controller.dao.PasswordDao;
import org.password.model.Password;
import org.password.utils.DBUtils;
import org.password.utils.SqlExecute;

public class PasswordDaoImplement extends SqlExecute implements PasswordDao {

	@Override
	public boolean createPassword(Password password) {
		String sql = "insert into password(passwordName,passwordCode,passwordText,personId) value (?,?,?,?)";
		String passwordName = password.getPasswordName();
		String passwordCode = password.getPasswordCode();
		String passwordText = password.getPasswordText();
		int personId = password.getPersonId();
		Object[] objects = {passwordName,passwordCode,passwordText,personId};
		boolean b = sqlExecuteUpdate(sql, objects);
		return b;
	}

	@Override
	public List<Password> showPassword(int personId) {
		String sql = "select * from password where personId = ?";
		Object[] objects = {personId};
		ResultSet rs = sqlExecutteQuery(sql, objects);
		List<Password> list = new ArrayList<Password>();
		try {
			while(rs.next()) {
				int passwordId = rs.getInt("passwordId");
				String passwordText = rs.getString("passwordText");
				String passwordCode = rs.getString("passwordCode");
				String passwordName = rs.getString("passwordName");
				Password password = new Password(passwordId, passwordName, passwordCode, passwordText, personId);
				list.add(password);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			close(rs);
		}
		return list;
	}
	
	@Override
	public Password showPasswordSingle(int passwordId) {
		String sql = "select * from password where passwordId = ?";
		Object[] objects = {passwordId};
		ResultSet rs = sqlExecutteQuery(sql, objects);
		Password password = null;

		try {
			if(rs.next()) {
				String passwordText = rs.getString("passwordText");
				String passwordCode = rs.getString("passwordCode");
				String passwordName = rs.getString("passwordName");
				int personId = rs.getInt("personId");
				password = new Password(passwordId, passwordName, passwordCode, passwordText, personId);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			close(rs);
		}
		return password;
	}

	@Override
	public boolean updatePassword(Password password) {
		String sql = "update password set passwordName = ? , passwordCode = ? , passwordText = ? where passwordId = ?";
		String passwordCode = password.getPasswordCode();
		String passwordText = password.getPasswordText();
		String passwordName = password.getPasswordName();
		int passwordId  = password.getPasswordId();
		Object[] objects = {passwordName,passwordCode,passwordText,passwordId};
		boolean b = sqlExecuteUpdate(sql, objects);
		return b;
	}

	@Override
	public boolean deletePassword(int passwordId) {
		String sql = "delete from password where passwordId = ?";
		Object[] objects = {passwordId};
		boolean b = sqlExecuteUpdate(sql, objects);
		return b;
	}
	

}
