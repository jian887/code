package org.password.controller.dao;

import java.util.List;

import org.password.model.Password;

public interface PasswordDao {

	/**
	 * 创建密码
	 * @param password
	 * @return
	 */
	public boolean createPassword(Password password);
	
	/**
	 * 显示密码
	 * @return
	 */
	public List<Password> showPassword(int personId);
	
	/**
	 * 通过ID查找密码信息
	 * @param passwordId
	 * @return
	 */
	public Password showPasswordSingle(int passwordId);
	
	/**
	 * 修改密码信息
	 * @param password
	 * @return
	 */
	public boolean updatePassword(Password password);
	
	/**
	 * 删除密码信息
	 * @param passwordId
	 * @return
	 */
	public boolean deletePassword(int passwordId);
}
