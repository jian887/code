package org.password.server;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.password.controller.dao.PersonDao;
import org.password.controller.implement.PersonDaoImplement;
import org.password.model.Person;

/**
 * <servelt>
 * <servlet-name>abc<servlet-name>
 * <servlet-class>org.password.server.PersonServer</servlet-class>
 * </servlet>
 * 
 * <servlet-mapping>
 * <servlet-name>abc</servlet-name>
 * <url-pattern>/personServer</url-pattern>
 * </servlet-mapping>
 * 
 * @author admin
 *
 */
//@WebServlet("/personServer")
public class PersonServer extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private String op = null;
	private String path = null;
	
	public PersonServer() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		op = request.getParameter("op");
		if(op == "regist" || "regist".equals(op)) {
			this.personRegistServer(request, response);
		}else if(op == "login" || "login".equals(op)) {
			this.personLoginServer(request, response);
		}
		request.getRequestDispatcher(path).forward(request, response);
	}
	
	protected void personRegistServer(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String personName = request.getParameter("personName");
		String personPassword = request.getParameter("personPassword");
		Person person = new Person(personName, personPassword);
		PersonDao personDao = new PersonDaoImplement();
		boolean b = personDao.personRegist(person);
		if(b) {
			path = "view/login.jsp";
		}else {
			path = "view/regist.jsp";
		}
	}
	
	protected void personLoginServer(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String personName = request.getParameter("personName");
		String personPassword = request.getParameter("personPassword");
		Person person = new Person(personName, personPassword);
		PersonDao personDao = new PersonDaoImplement();
		person = personDao.personLogin(person);
		if(person != null) {
			request.getSession().setAttribute("person", person);
			path = "/passwordServer?op=show";
		}else {
			path = "view/login.jsp";
		}
	}

}
