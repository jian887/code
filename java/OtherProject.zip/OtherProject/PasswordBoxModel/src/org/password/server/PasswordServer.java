package org.password.server;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.password.controller.dao.PasswordDao;
import org.password.controller.implement.PasswordDaoImplement;
import org.password.model.Password;
import org.password.model.Person;

/**
 * Servlet implementation class PasswordServer
 */
//@WebServlet("/passwordServer")
public class PasswordServer extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String op = null;
	private String path = null;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		op = request.getParameter("op");
		if(op == "show" || "show".equals(op)) {
			this.showPasswordServer(request, response);
		}else if(op == "create" || "create".equals(op)) {
			this.createPasswordServer(request, response);
		}else if(op == "showsingle" || "showsingle".equals(op)) {
			this.showSinglePasswordServer(request, response);
		}else if(op == "update" || "update".equals(op)) {
			this.updatePasswordServer(request, response);
		}else if(op == "del" || "del".equals(op)) {
			this.deletePasswordServer(request, response);
		}
		request.getRequestDispatcher(path).forward(request, response);
	}
	protected void temp(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}
	
	protected void createPasswordServer(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String passwordCode = request.getParameter("passwordCode");
		String passwordText = request.getParameter("passwordText");
		String passwordName = request.getParameter("passwordName");
		Person person = (Person)request.getSession().getAttribute("person");
		int personId = person.getPersonId();
		Password password = new Password(passwordName, passwordCode, passwordText, personId);
		PasswordDao passwordDao = new PasswordDaoImplement();
		boolean b = passwordDao.createPassword(password);
		if(b) {
			path = "/passwordServer?op=show";
		}
		
		

	}
	
	protected void showPasswordServer(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Person person = (Person)request.getSession().getAttribute("person");
		int personId = person.getPersonId();
		PasswordDao passwordDao = new PasswordDaoImplement();
		List<Password> passwords = passwordDao.showPassword(personId);
		request.setAttribute("passwords", passwords);
		path= "view/show.jsp";

	}
	
	protected void showSinglePasswordServer(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int passwordId = Integer.parseInt(request.getParameter("passwordId"));
		PasswordDao passwordDao = new PasswordDaoImplement();
		Password password = passwordDao.showPasswordSingle(passwordId);
		if(password != null) {
			request.setAttribute("password", password);
			path = "view/update.jsp";
		}else {
			path = "view/login.jsp";
		}
		
				
	}
	
	protected void updatePasswordServer(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int passwordId = Integer.parseInt(request.getParameter("passwordId"));
		String passwordCode = request.getParameter("passwordCode");
		String passwordText = request.getParameter("passwordText");
		String passwordName = request.getParameter("passwordName");
		PasswordDao passwordDao = new PasswordDaoImplement();
		Password password = new Password(passwordId, passwordName, passwordCode, passwordText);
		boolean b = passwordDao.updatePassword(password);
		if(b) {
			path = "/passwordServer?op=show";
		}else {
			path = "view/login.jsp";
		}
		

	}
	
	protected void deletePasswordServer(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int passwordId = Integer.parseInt(request.getParameter("passwordId"));
		PasswordDao passwordDao = new PasswordDaoImplement();
		boolean b = passwordDao.deletePassword(passwordId);
		if(b) {
			path = "/passwordServer?op=show";
		}else {
			path = "view/login.jsp";
		}
		
	}

}
