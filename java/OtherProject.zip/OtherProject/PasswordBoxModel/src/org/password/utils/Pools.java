package org.password.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

/**
 * 小型项目可以使用该连接池，如果涉及到大型项目，应该使用专业的是数据库连接池管理工具。
 * C3P0
 * @author admin
 *
 */
public class Pools {

	private static final String url="jdbc:mysql://localhost:3307/password";
	private static final String driver="com.mysql.jdbc.Driver";
	private static final String user="root";
	private static final String password="123456";
	private static Connection con = null;
	private static LinkedList<Connection> pool = new LinkedList<Connection>();
	
	static {
		try {
			Class.forName(driver);
			for(int i = 0 ; i < 10 ; i++) {
				//往连接池中追加数据库连接
				pool.addLast(getPoolConnection());
			}
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 创建连接尺寸装载数据库连接
	 * @return
	 */
	public static Connection getPoolConnection() {
		try {
			con = DriverManager.getConnection(url, user, password);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return  con;
	}
	
	/**
	 * 从连接池中取出连接
	 * @return
	 */
	public static Connection getConnection() {
		con = pool.removeFirst();
		return con;
	}
	
	/**
	 * 把使用之后的数据库连接放回连接池中
	 * @param con
	 */
	public static void free(Connection con) {
		pool.addLast(con);
	}
}
