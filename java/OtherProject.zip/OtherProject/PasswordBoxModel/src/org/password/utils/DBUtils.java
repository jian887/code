package org.password.utils;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBUtils extends Pools {

	private static Connection con = null;

	/**
	 * 获取数据库连接
	 * 
	 * @return
	 */
	public static Connection getDBUtilsConnection() {
		con = getConnection();
		return con;
	}

	/**
	 * 关闭顺序 rs -- pstmt --con
	 * 
	 * @param con
	 * @param pstmt
	 * @param rs
	 */
	public static void close(Connection con, Statement pstmt, ResultSet rs) {
		try {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
					pstmt = null;
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
					if (con != null) {
						free(con);
					}
			}
		}
	}
}
