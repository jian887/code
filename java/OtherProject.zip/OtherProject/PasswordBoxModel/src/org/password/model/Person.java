package org.password.model;

import java.util.Date;

/**
 * @author LRJ Tue May 29 09:55:49 CST 2018
 *         <p>
 *         person 实体类
 *         </P>
 */

public class Person {
	private int personId;
	private String personName;
	private String personPassword;
	private Date personRegistTime;

	public Person() {
	};

	public Person(int personId, String personName, String personPassword, Date personRegistTime) {
		super();
		this.personId = personId;
		this.personName = personName;
		this.personPassword = personPassword;
		this.personRegistTime = personRegistTime;
	}
	
	public Person( String personName, String personPassword) {
		super();
		this.personName = personName;
		this.personPassword = personPassword;
	}

	public void setPersonId(int personId) {
		this.personId = personId;
	}

	public int getPersonId() {
		return personId;
	}

	public void setPersonName(String personName) {
		this.personName = personName;
	}

	public String getPersonName() {
		return personName;
	}

	public String getPersonPassword() {
		return personPassword;
	}

	public void setPersonPassword(String personPassword) {
		this.personPassword = personPassword;
	}

	public void setPersonRegistTime(Date personRegistTime) {
		this.personRegistTime = personRegistTime;
	}

	public Date getPersonRegistTime() {
		return personRegistTime;
	}
}
