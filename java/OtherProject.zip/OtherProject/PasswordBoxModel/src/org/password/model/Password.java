package org.password.model;

/**
 * @author LRJ Tue May 29 09:55:49 CST 2018
 *         <p>
 *         password 实体类
 *         </P>
 */

public class Password {
	private int passwordId;
	private String passwordName;
	private String passwordCode;
	private String passwordText;
	private int personId;

	public Password() {
	};

	public Password(int passwordId, String passwordName ,String passwordCode, String passwordText, int personId) {
		super();
		this.passwordId = passwordId;
		this.passwordName = passwordName;
		this.passwordCode = passwordCode;
		this.passwordText = passwordText;
		this.personId = personId;
	}

	public Password( String passwordName,String passwordCode, String passwordText, int personId) {
		super();
		this.passwordName = passwordName;
		this.passwordCode = passwordCode;
		this.passwordText = passwordText;
		this.personId = personId;
	}
	
	

	public Password(int passwordId, String passwordName, String passwordCode, String passwordText) {
		super();
		this.passwordId = passwordId;
		this.passwordName = passwordName;
		this.passwordCode = passwordCode;
		this.passwordText = passwordText;
	}

	public void setPasswordId(int passwordId) {
		this.passwordId = passwordId;
	}

	public int getPasswordId() {
		return passwordId;
	}

	public void setPasswordCode(String passwordCode) {
		this.passwordCode = passwordCode;
	}

	public String getPasswordCode() {
		return passwordCode;
	}

	public void setPasswordText(String passwordText) {
		this.passwordText = passwordText;
	}

	public String getPasswordText() {
		return passwordText;
	}

	public void setPersonId(int personId) {
		this.personId = personId;
	}

	public int getPersonId() {
		return personId;
	}

	public String getPasswordName() {
		return passwordName;
	}

	public void setPasswordName(String passwordName) {
		this.passwordName = passwordName;
	}

}
