import cn.jerryshell.util.MD5SaltUtil;

public class MD5SaltUtilTest {

	public static void main(String[] args) {
		String md5 = MD5SaltUtil.MD5Base64("test");
		System.out.println(md5);
	}
}
