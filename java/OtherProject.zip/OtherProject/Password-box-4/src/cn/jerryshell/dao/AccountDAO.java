package cn.jerryshell.dao;

import java.util.List;

import cn.jerryshell.entity.Account;

public interface AccountDAO {

	/**
	 * 添加账号
	 * 
	 * @param account
	 */
	public void addAccount(Account account);

	/**
	 * 更新账号
	 * 
	 * @param account
	 */
	public void updateAccount(Account account);

	/**
	 * 删除账号
	 * 
	 * @param id
	 */
	public void deleteAccount(int id);

	/**
	 * 通过 id 获得账号
	 * 
	 * @param id
	 * @return
	 */
	public Account getAccountById(int id);

	/**
	 * 通过用户 id 和账号状态获得账号列表
	 * 
	 * @param userId
	 * @param status
	 * @return
	 */
	public List<Account> getAccountListByUserIdAndStatus(int userId, int status);

	/**
	 * 通过用户 id 获得账号总数
	 * 
	 * @param userId
	 * @return
	 */
	public int getAccountTotalByUserId(int userId);
}
