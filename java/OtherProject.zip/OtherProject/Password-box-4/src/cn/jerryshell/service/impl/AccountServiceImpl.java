package cn.jerryshell.service.impl;

import java.util.List;

import cn.jerryshell.dao.AccountDAO;
import cn.jerryshell.dao.impl.AccountDAOImpl;
import cn.jerryshell.entity.Account;
import cn.jerryshell.service.AccountService;

public class AccountServiceImpl implements AccountService {
	private AccountDAO accountDAO = new AccountDAOImpl();

	@Override
	public void addAccount(int userId, String password, String info) {
		Account account = new Account();
		account.setUserId(userId);
		account.setPassword(password);
		account.setInfo(info);
		account.setStatus(Account.STATUS_NORMAL);

		accountDAO.addAccount(account);
	}

	@Override
	public void deleteAccount(int id) {
		accountDAO.deleteAccount(id);
	}

	@Override
	public void updateAccount(int id, int userId, String password, String info, int status) {
		Account account = new Account();
		account.setId(id);
		account.setUserId(userId);
		account.setPassword(password);
		account.setInfo(info);
		account.setStatus(status);

		accountDAO.updateAccount(account);
	}

	@Override
	public Account getAccountById(int id) {
		Account account = accountDAO.getAccountById(id);
		return account;
	}

	@Override
	public List<Account> getNormalAccountListByUserId(int userId) {
		List<Account> accountList = accountDAO.getAccountListByUserIdAndStatus(userId, Account.STATUS_NORMAL);
		return accountList;
	}

	@Override
	public List<Account> getTrashAccountListByUserId(int userId) {
		List<Account> accountList = accountDAO.getAccountListByUserIdAndStatus(userId, Account.STATUS_TRASH);
		return accountList;
	}

}
