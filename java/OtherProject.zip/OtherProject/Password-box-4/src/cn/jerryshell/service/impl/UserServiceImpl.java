package cn.jerryshell.service.impl;

import cn.jerryshell.dao.UserDAO;
import cn.jerryshell.dao.impl.UserDAOImpl;
import cn.jerryshell.entity.User;
import cn.jerryshell.service.UserService;
import cn.jerryshell.util.MD5SaltUtil;

public class UserServiceImpl implements UserService {
	private UserDAO userDAO = new UserDAOImpl();

	@Override
	public User register(String username, String password, String email) {
		password = MD5SaltUtil.MD5Base64(password);

		User user = new User();
		user.setUsername(username);
		user.setPassword(password);
		user.setEmail(email);
		userDAO.addUser(user);
		return user;
	}

	@Override
	public void deleteUser(int id) {
		userDAO.deleteUser(id);
	}

	@Override
	public User updateUser(int id, String username, String password, String email) {
		password = MD5SaltUtil.MD5Base64(password);

		User user = new User();
		user.setId(id);
		user.setUsername(username);
		user.setPassword(password);
		user.setEmail(email);
		userDAO.updateUser(user);
		return user;
	}

	@Override
	public User login(String username, String password) {
		password = MD5SaltUtil.MD5Base64(password);

		User user = userDAO.getUserByUsernameAndPassword(username, password);
		return user;
	}

	@Override
	public User findUserById(int id) {
		User user = userDAO.getUserById(id);
		return user;
	}

	@Override
	public User findUserByUsername(String username) {
		User user = userDAO.getUserByUsername(username);
		return user;
	}

}
