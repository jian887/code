package cn.jerryshell.entity;

public class Account {

	// 账号状态：正常
	public static final int STATUS_NORMAL = 0;
	// 账号状态：已放入回收站
	public static final int STATUS_TRASH = 1;

	private int id;
	private int userId;
	private String password;
	private String info;
	private int status;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Account [id=" + id + ", userId=" + userId + ", password=" + password + ", info=" + info + ", status="
				+ status + "]";
	}

}
