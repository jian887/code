package cn.jerryshell.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cn.jerryshell.entity.SecurityQuestion;
import cn.jerryshell.entity.User;
import cn.jerryshell.service.LoginHistoryService;
import cn.jerryshell.service.SecurityQuestionService;
import cn.jerryshell.service.UserService;
import cn.jerryshell.service.impl.LoginHistoryServiceImpl;
import cn.jerryshell.service.impl.SecurityQuestionServiceImpl;
import cn.jerryshell.service.impl.UserServiceImpl;
import cn.jerryshell.util.Captcha;
import cn.jerryshell.util.ControllerUtil;
import cn.jerryshell.util.MD5SaltUtil;

@WebServlet("/user")
public class UserController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private UserService userService = new UserServiceImpl();
	private LoginHistoryService loginHistoryService = new LoginHistoryServiceImpl();
	private SecurityQuestionService securityQuestionService = new SecurityQuestionServiceImpl();

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String path = "message.jsp";
		String action = request.getParameter("action");
		if ("register".equals(action)) {
			path = register(request, response);
		} else if ("login".equals(action)) {
			path = login(request, response);
		} else if ("logout".equals(action)) {
			path = logout(request, response);
		} else if ("updateInfo".equals(action)) {
			path = updateInfo(request, response);
		} else if ("updatePassword".equals(action)) {
			path = updatePassword(request, response);
		} else if ("createSecurityQuestion".equals(action)) {
			path = createSecurityQuestion(request, response);
		} else if ("updateSecurityQuestionUI".equals(action)) {
			path = updateSecurityQuestionUI(request, response);
		} else if ("updateSecurityQuestion".equals(action)) {
			path = updateSecurityQuestion(request, response);
		} else if ("resetPasswordStep1".equals(action)) {
			path = resetPasswordStep1(request, response);
		} else if ("resetPasswordStep2".equals(action)) {
			path = resetPasswordStep2(request, response);
		} else if ("resetPasswordStep3".equals(action)) {
			path = resetPasswordStep3(request, response);
		} else {
			request.setAttribute("message", "未知操作");
		}
		request.getRequestDispatcher(path).forward(request, response);
	}

	private String createSecurityQuestion(HttpServletRequest request, HttpServletResponse response) {
		String message = null;
		String question = request.getParameter("question");
		String answer = request.getParameter("answer");
		User user = (User) request.getSession().getAttribute("user");
		SecurityQuestion securityQuestion = securityQuestionService.getSecurityQuestionByUserId(user.getId());
		if (securityQuestion != null) {
			message = "请勿重复创建密保问题";
		} else if (ControllerUtil.isEmpty(question, answer)) {
			message = "字段不能为空";
		} else {
			securityQuestionService.createSecurityQuestion(user.getId(), question, answer);
			message = "密保问题设置成功！";
		}
		request.setAttribute("message", message);
		return "message.jsp";
	}

	private String login(HttpServletRequest request, HttpServletResponse response) {
		String message = null;
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String captchaStr = request.getParameter("captcha");
		HttpSession session = request.getSession();
		Captcha captcha = (Captcha) session.getAttribute("captcha");
		if (ControllerUtil.isEmpty(username, password)) {
			message = "字段不能为空";
		} else if (!captchaStr.equals(captcha.getCaptchaStr())) {
			message = "验证码错误";
		} else {
			User user = userService.login(username, password);
			if (user == null) {
				message = "用户名或密码错误";
			} else {
				session.setAttribute("user", user);
				loginHistoryService.addLoginHistory(user.getId());
				message = "登录成功！";
			}
		}
		request.setAttribute("message", message);
		return "message.jsp";
	}

	private String logout(HttpServletRequest request, HttpServletResponse response) {
		String message = null;
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		if (user == null) {
			message = "未登录，注销失败";
		} else {
			session.invalidate();
			message = "注销成功!";
		}
		request.setAttribute("message", message);
		return "message.jsp";
	}

	private String register(HttpServletRequest request, HttpServletResponse response) {
		String message = null;
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String password2 = request.getParameter("password2");
		String email = request.getParameter("email");
		String captchaStr = request.getParameter("captcha");
		Captcha captcha = (Captcha) request.getSession().getAttribute("captcha");
		if (ControllerUtil.isEmpty(username, password, password2, email, captchaStr)) {
			message = "字段不能为空";
		} else if (!captchaStr.equals(captcha.getCaptchaStr())) {
			message = "验证码错误";
		} else if (!password.equals(password2)) {
			message = "确认密码不一致";
		} else {
			User user = userService.findUserByUsername(username);
			if (user != null) {
				message = "用户名已被注册！";
			} else {
				userService.register(username, password, email);
				message = "注册成功！";
			}
		}
		request.setAttribute("message", message);
		return "message.jsp";
	}

	private String resetPasswordStep1(HttpServletRequest request, HttpServletResponse response) {
		String message = null;
		String username = request.getParameter("username");
		if (ControllerUtil.isEmpty(username)) {
			message = "字段不能为空";
		} else {
			User user = userService.findUserByUsername(username);
			if (user == null) {
				message = "该用户不存在";
			} else {
				HttpSession session = request.getSession();
				session.setAttribute("resetPasswordUser", user);
				session.setAttribute("canReset", false);
				SecurityQuestion securityQuestion = securityQuestionService.getSecurityQuestionByUserId(user.getId());
				if (securityQuestion == null) {
					securityQuestion = new SecurityQuestion();
					securityQuestion.setQuestion("未设置密保问题，请输入注册邮箱");
					securityQuestion.setAnswer(user.getEmail());
					securityQuestion.setUserId(user.getId());
				}
				session.setAttribute("securityQuestion", securityQuestion);
				return "user/resetPasswordStep2.jsp";
			}
		}
		request.setAttribute("message", message);
		return "message.jsp";
	}

	private String resetPasswordStep2(HttpServletRequest request, HttpServletResponse response) {
		String message = null;
		String answer = request.getParameter("answer");
		if (ControllerUtil.isEmpty(answer)) {
			message = "字段不能为空";
		} else {
			HttpSession session = request.getSession();
			User user = (User) session.getAttribute("resetPasswordUser");
			SecurityQuestion securityQuestion = (SecurityQuestion) session.getAttribute("securityQuestion");
			if (user == null || securityQuestion == null) {
				message = "请先完成第一步";
			} else if (!answer.equals(securityQuestion.getAnswer())) {
				message = "回答错误";
			} else {
				session.setAttribute("canReset", true);
				return "user/resetPasswordStep3.jsp";
			}
		}
		request.setAttribute("message", message);
		return "message.jsp";
	}

	private String resetPasswordStep3(HttpServletRequest request, HttpServletResponse response) {
		String message = null;
		String password = request.getParameter("password");
		String password2 = request.getParameter("password2");
		if (ControllerUtil.isEmpty(password, password2)) {
			message = "字段不能为空";
		} else if (!password.equals(password2)) {
			message = "两次密码不一致";
		} else {
			HttpSession session = request.getSession();
			Object canReset = session.getAttribute("canReset");
			if (canReset == null || !(boolean) canReset) {
				message = "请正确回答问题";
			} else {
				User user = (User) session.getAttribute("resetPasswordUser");
				if (user == null) {
					message = "请先完成第一步";
				} else {
					user.setPassword(password);
					userService.updateUser(user.getId(), user.getUsername(), user.getPassword(), user.getEmail());
					message = "修改密码成功！";
					session.invalidate();
				}
			}
		}
		request.setAttribute("message", message);
		return "message.jsp";
	}

	private String updateInfo(HttpServletRequest request, HttpServletResponse response) {
		String message = null;
		String email = request.getParameter("email");
		if (ControllerUtil.isEmpty(email)) {
			message = "字段不能为空";
		} else {
			User user = (User) request.getSession().getAttribute("user");
			if (user == null) {
				message = "请先登录！";
			} else {
				user.setEmail(email);
				userService.updateUser(user.getId(), user.getUsername(), user.getPassword(), user.getEmail());
				message = "更新个人信息成功！";
			}
		}
		request.setAttribute("message", message);
		return "message.jsp";
	}

	private String updatePassword(HttpServletRequest request, HttpServletResponse response) {
		String message = null;
		String currentPassword = request.getParameter("currentPassword");
		String password = request.getParameter("password");
		String password2 = request.getParameter("password2");
		if (ControllerUtil.isEmpty(currentPassword, password, password2)) {
			message = "字段不能为空";
		} else if (!password.equals(password2)) {
			message = "确认密码不一致";
		} else {
			HttpSession session = request.getSession();
			User user = (User) session.getAttribute("user");
			if (user == null) {
				message = "请先登录！";
			} else {
				currentPassword = MD5SaltUtil.MD5Base64(currentPassword);
				if (!currentPassword.equals(user.getPassword())) {
					message = "修改密码失败，请正确输入当前密码";
				} else {
					user.setPassword(password);
					userService.updateUser(user.getId(), user.getUsername(), user.getPassword(), user.getEmail());
					message = "修改密码成功，请重新登录";
					session.invalidate();
				}
			}
		}
		request.setAttribute("message", message);
		return "message.jsp";
	}

	private String updateSecurityQuestion(HttpServletRequest request, HttpServletResponse response) {
		String message = null;
		String idStr = request.getParameter("id");
		int id = Integer.parseInt(idStr);
		String question = request.getParameter("question");
		String answer = request.getParameter("answer");
		if (ControllerUtil.isEmpty(question, answer)) {
			message = "字段不能为空";
		} else {
			User user = (User) request.getSession().getAttribute("user");
			securityQuestionService.updateSecurityQuestion(id, user.getId(), question, answer);
			message = "密保问题修改成功！";
		}
		request.setAttribute("message", message);
		return "message.jsp";
	}

	private String updateSecurityQuestionUI(HttpServletRequest request, HttpServletResponse response) {
		User user = (User) request.getSession().getAttribute("user");
		SecurityQuestion securityQuestion = securityQuestionService.getSecurityQuestionByUserId(user.getId());
		if (securityQuestion == null) {
			request.setAttribute("message", "密保问题必须先创建才能被修改！");
			return "message.jsp";
		}
		request.setAttribute("securityQuestion", securityQuestion);
		return "user/updateSecurityQuestion.jsp";
	}
}
