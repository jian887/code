package cn.jerryshell.controller;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.jerryshell.entity.Account;
import cn.jerryshell.entity.SecurityQuestion;
import cn.jerryshell.entity.User;
import cn.jerryshell.service.AccountService;
import cn.jerryshell.service.LoginHistoryService;
import cn.jerryshell.service.SecurityQuestionService;
import cn.jerryshell.service.impl.AccountServiceImpl;
import cn.jerryshell.service.impl.LoginHistoryServiceImpl;
import cn.jerryshell.service.impl.SecurityQuestionServiceImpl;
import cn.jerryshell.util.ControllerUtil;

@WebServlet("/account")
public class AccountController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private AccountService accountService = new AccountServiceImpl();
	private LoginHistoryService loginHistoryService = new LoginHistoryServiceImpl();
	private SecurityQuestionService securityQuestionService = new SecurityQuestionServiceImpl();

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String path = "message.jsp";
		String action = request.getParameter("action");
		if ("list".equals(action)) {
			path = list(request, response);
		} else if ("trashList".equals(action)) {
			path = trashList(request, response);
		} else if ("addAccount".equals(action)) {
			path = addAccount(request, response);
		} else if ("deleteAccount".equals(action)) {
			path = deleteAccount(request, response);
		} else if ("updateAccountUI".equals(action)) {
			path = updateAccountUI(request, response);
		} else if ("updateAccount".equals(action)) {
			path = updateAccount(request, response);
		} else if ("trashAccount".equals(action)) {
			path = trashAccount(request, response);
		} else if ("restoreAccount".equals(action)) {
			path = restoreAccount(request, response);
		} else {
			request.setAttribute("message", "未知操作");
		}
		if (path == null) {
			return;
		}
		request.getRequestDispatcher(path).forward(request, response);
	}

	@SuppressWarnings("deprecation")
	private String list(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		User user = (User) request.getSession().getAttribute("user");

		List<Account> accountList = accountService.getNormalAccountListByUserId(user.getId());
		request.setAttribute("accountList", accountList);

		int loginTotal = loginHistoryService.getLoginTotalNumberByUserId(user.getId());
		request.setAttribute("loginTotal", loginTotal);

		String lastLoginDate = "无";
		List<Date> dateList = loginHistoryService.getRecently2LoginDateTimeByUserId(user.getId());
		if (dateList.size() == 2) {
			lastLoginDate = dateList.get(1).toLocaleString();
		}
		request.setAttribute("lastLoginDate", lastLoginDate);

		SecurityQuestion securityQuestion = securityQuestionService.getSecurityQuestionByUserId(user.getId());
		boolean isSecurity = (securityQuestion != null);
		request.setAttribute("isSecurity", isSecurity);
		return "account/accountList.jsp";
	}

	private String trashList(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		User user = (User) request.getSession().getAttribute("user");
		List<Account> accountList = accountService.getTrashAccountListByUserId(user.getId());
		request.setAttribute("accountList", accountList);
		return "account/trashAccountList.jsp";
	}

	private String addAccount(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String password = request.getParameter("password");
		String info = request.getParameter("info");
		if (ControllerUtil.isEmpty(password, info)) {
			request.setAttribute("message", "字段不能为空");
			return "message.jsp";
		}
		User user = (User) request.getSession().getAttribute("user");
		accountService.addAccount(user.getId(), password, info);
		response.sendRedirect(request.getContextPath() + "/account?action=list");
		return null;
	}

	private String deleteAccount(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String idStr = request.getParameter("id");
		int id = Integer.parseInt(idStr);
		User user = (User) request.getSession().getAttribute("user");
		Account account = accountService.getAccountById(id);
		if (user.getId() == account.getUserId()) {
			accountService.deleteAccount(id);
		}
		response.sendRedirect(request.getContextPath() + "/account?action=trashList");
		return null;
	}

	private String trashAccount(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String idStr = request.getParameter("id");
		int id = Integer.parseInt(idStr);
		User user = (User) request.getSession().getAttribute("user");
		Account account = accountService.getAccountById(id);
		if (user.getId() == account.getUserId()) {
			accountService.updateAccount(id, user.getId(), account.getPassword(), account.getInfo(),
					Account.STATUS_TRASH);
		}
		response.sendRedirect(request.getContextPath() + "/account?action=list");
		return null;
	}

	private String restoreAccount(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String idStr = request.getParameter("id");
		int id = Integer.parseInt(idStr);
		User user = (User) request.getSession().getAttribute("user");
		Account account = accountService.getAccountById(id);
		if (user.getId() == account.getUserId()) {
			accountService.updateAccount(id, user.getId(), account.getPassword(), account.getInfo(),
					Account.STATUS_NORMAL);
		}
		response.sendRedirect(request.getContextPath() + "/account?action=list");
		return null;
	}

	private String updateAccountUI(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String idStr = request.getParameter("id");
		int id = Integer.parseInt(idStr);
		User user = (User) request.getSession().getAttribute("user");
		Account account = accountService.getAccountById(id);
		if (user.getId() == account.getUserId()) {
			request.setAttribute("account", account);
		}
		return "account/updateAccount.jsp";
	}

	private String updateAccount(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String message = null;
		String idStr = request.getParameter("id");
		String password = request.getParameter("password");
		String info = request.getParameter("info");
		String statusStr = request.getParameter("status");
		if (ControllerUtil.isEmpty(idStr, password, info, statusStr)) {
			message = "字段不能为空";
		} else {
			int status = Integer.parseInt(statusStr);
			if (status != Account.STATUS_NORMAL && status != Account.STATUS_TRASH) {
				message = "非法状态代号";
			} else {
				int id = Integer.parseInt(idStr);
				User user = (User) request.getSession().getAttribute("user");
				Account account = accountService.getAccountById(id);
				if (user.getId() == account.getUserId()) {
					accountService.updateAccount(id, user.getId(), password, info, status);
				}
				response.sendRedirect(request.getContextPath() + "/account?action=list");
				return null;
			}
		}
		request.setAttribute("message", message);
		return "message.jsp";
	}

}
