package cn.jerryshell.util;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.Base64.Encoder;
import java.util.Properties;

public class MD5SaltUtil {

	private static String SALT = null;

	static {
		Properties properties = new Properties();
		try {
			properties.load(MD5SaltUtil.class.getResourceAsStream("MD5SaltUtil.properties"));
			SALT = properties.getProperty("salt");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static String MD5Base64(String password) {
		String md5 = null;
		password += SALT;
		try {
			MessageDigest messageDigest = MessageDigest.getInstance("MD5");
			byte[] digest = messageDigest.digest(password.getBytes());
			Encoder encoder = Base64.getEncoder();
			md5 = encoder.encodeToString(digest);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		return md5;
	}
}
