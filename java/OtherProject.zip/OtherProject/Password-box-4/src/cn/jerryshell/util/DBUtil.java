package cn.jerryshell.util;

import java.beans.PropertyVetoException;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import com.mchange.v2.c3p0.ComboPooledDataSource;

public class DBUtil {

	private static String JDBC_URL = null;
	private static String USERNAME = null;
	private static String PASSWORD = null;
	private static ComboPooledDataSource cpds = new ComboPooledDataSource();

	static {
		try {
			Properties properties = new Properties();
			properties.load(DBUtil.class.getResourceAsStream("db.properties"));
			String dbms = properties.getProperty("dbms");
			String ip = properties.getProperty("ip");
			String port = properties.getProperty("port");
			String database = properties.getProperty("database");
			JDBC_URL = String.format("jdbc:%s://%s:%s/%s", dbms, ip, port, database);
			USERNAME = properties.getProperty("username");
			PASSWORD = properties.getProperty("password");

			cpds.setDriverClass("com.mysql.jdbc.Driver");
			cpds.setJdbcUrl(JDBC_URL);
			cpds.setUser(USERNAME);
			cpds.setPassword(PASSWORD);
		} catch (PropertyVetoException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public static Connection getConnection() {
		Connection connection = null;
		try {
			connection = cpds.getConnection();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if (connection == null) {
			throw new RuntimeException("与数据库建立连接失败");
		}
		return connection;
	}

	public static void close(Connection connection, Statement statement, ResultSet resultSet) {
		try {
			if (resultSet != null) {
				resultSet.close();
			}
			if (statement != null) {
				statement.close();
			}
			if (connection != null) {
				connection.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
