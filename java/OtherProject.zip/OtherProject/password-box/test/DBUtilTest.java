
import java.sql.Connection;

import cn.jerryshell.util.DBUtil;

public class DBUtilTest {

	public static void main(String[] args) {
		Connection connection = DBUtil.getConnection();
		System.out.println(connection);
	}

}
