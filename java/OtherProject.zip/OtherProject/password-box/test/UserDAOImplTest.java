
import java.util.List;

import cn.jerryshell.dao.UserDAO;
import cn.jerryshell.dao.impl.UserDAOImpl;
import cn.jerryshell.entity.User;

public class UserDAOImplTest {

	public static UserDAO userDAO = new UserDAOImpl();

	public static void main(String[] args) {
		// addUser();
		// updateUser();
		// deleteUser();
		// getUserById();
		// getUserByUsernameAndPassword();
		// list();
		total();
	}

	public static void addUser() {
		User user = new User();
		user.setUsername("jerry");
		user.setPassword("helloworld");
		user.setEmail("jerry@email.com");

		userDAO.addUser(user);
	}

	public static void updateUser() {
		User user = new User();
		user.setId(1);
		user.setUsername("jerryUpdate");
		user.setPassword("helloworld");
		user.setEmail("jerry@email.com");

		userDAO.updateUser(user);
	}

	public static void deleteUser() {
		userDAO.deleteUser(2);
	}

	public static void getUserById() {
		User user = userDAO.getUserById(1);
		System.out.println(user);
	}

	public static void getUserByUsernameAndPassword() {
		User user = userDAO.getUserByUsernameAndPassword("jerryUpdate", "helloworld");
		System.out.println(user);
	}

	public static void list() {
		List<User> list = userDAO.list(0, 2);
		for (int i = 0, size = list.size(); i < size; i++) {
			System.out.println(list.get(i));
		}
	}

	public static void total() {
		int total = userDAO.total();
		System.out.println(total);
	}

}
