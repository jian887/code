
import java.util.List;

import cn.jerryshell.dao.AccountDAO;
import cn.jerryshell.dao.UserDAO;
import cn.jerryshell.dao.impl.AccountDAOImpl;
import cn.jerryshell.dao.impl.UserDAOImpl;
import cn.jerryshell.entity.Account;
import cn.jerryshell.entity.User;

public class AccountDAOImplTest {

	public static UserDAO userDAO = new UserDAOImpl();
	public static User user = userDAO.getUserById(1);
	public static AccountDAO accountDAO = new AccountDAOImpl();

	public static void main(String[] args) {
		// addAccount();
		// updateAccount();
		// deleteAccount();
		// getAccountListByUserId();
		getAccountTotalByUserId();
	}

	public static void addAccount() {
		Account account = new Account();
		account.setUserId(user.getId());
		account.setPassword("passwordtest");
		account.setInfo("infotest");
		accountDAO.addAccount(account);
	}

	public static void updateAccount() {
		Account account = accountDAO.getAccountById(1);
		account.setPassword("test");
		accountDAO.updateAccount(account);
	}

	public static void deleteAccount() {
		accountDAO.deleteAccount(2);
	}

	public static void getAccountListByUserId() {
		List<Account> list = accountDAO.getAccountListByUserId(1);
		for (Account account : list) {
			System.out.println(account);
		}
	}

	public static void getAccountTotalByUserId() {
		int total = accountDAO.getAccountTotalByUserId(1);
		System.out.println(total);
	}

}
