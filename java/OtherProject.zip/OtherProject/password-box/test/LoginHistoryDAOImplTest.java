
import java.util.Date;
import java.util.List;

import cn.jerryshell.dao.LoginHistoryDAO;
import cn.jerryshell.dao.UserDAO;
import cn.jerryshell.dao.impl.LoginHistoryDAOImpl;
import cn.jerryshell.dao.impl.UserDAOImpl;
import cn.jerryshell.entity.User;

public class LoginHistoryDAOImplTest {

	public static UserDAO userDAO = new UserDAOImpl();
	public static User user = userDAO.getUserById(1);
	public static LoginHistoryDAO loginHistoryDAO = new LoginHistoryDAOImpl();

	public static void main(String[] args) {
		// addLoginHistory();
		getRecently2LoginDateTimeById();
		// getLoginTotalNumberByUserId();
	}

	public static void addLoginHistory() {
		loginHistoryDAO.addLoginHistory(user.getId(), new Date());
	}

	@SuppressWarnings("deprecation")
	public static void getRecently2LoginDateTimeById() {
		List<Date> list = loginHistoryDAO.getRecently2LoginDateTimeByUserId(user.getId());
		for (Date date : list) {
			System.out.println(date.toLocaleString());
		}
	}

	public static void getLoginTotalNumberByUserId() {
		int total = loginHistoryDAO.getLoginTotalNumberByUserId(user.getId());
		System.out.println(total);
	}

}
