package cn.jerryshell.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import cn.jerryshell.dao.AccountDAO;
import cn.jerryshell.entity.Account;
import cn.jerryshell.util.DBUtil;

public class AccountDAOImpl implements AccountDAO {

	@Override
	public void addAccount(Account account) {
		String sql = "insert into account(user_id, password, info) value(?,?,?)";
		Connection connection = DBUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		try {
			statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			statement.setObject(1, account.getUserId());
			statement.setObject(2, account.getPassword());
			statement.setObject(3, account.getInfo());

			statement.executeUpdate();
			resultSet = statement.getGeneratedKeys();
			if (resultSet.next()) {
				int id = resultSet.getInt(1);
				account.setId(id);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(connection, statement, resultSet);
		}
	}

	@Override
	public void updateAccount(Account account) {
		String sql = "update account set password=?,info=? where id=?";
		Connection connection = DBUtil.getConnection();
		PreparedStatement statement = null;
		try {
			statement = connection.prepareStatement(sql);
			statement.setObject(1, account.getPassword());
			statement.setObject(2, account.getInfo());
			statement.setObject(3, account.getId());

			statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void deleteAccount(int id) {
		String sql = "delete from account where id=?";
		Connection connection = DBUtil.getConnection();
		PreparedStatement statement = null;
		try {
			statement = connection.prepareStatement(sql);
			statement.setObject(1, id);

			statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public Account getAccountById(int id) {
		Account account = null;
		String sql = "select user_id, password, info from account where id=?";
		Connection connection = DBUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		try {
			statement = connection.prepareStatement(sql);
			statement.setObject(1, id);

			resultSet = statement.executeQuery();
			if (resultSet.next()) {
				int userId = resultSet.getInt("user_id");
				String password = resultSet.getString("password");
				String info = resultSet.getString("info");

				account = new Account();
				account.setId(id);
				account.setUserId(userId);
				account.setPassword(password);
				account.setInfo(info);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return account;
	}

	@Override
	public List<Account> getAccountListByUserId(int userId) {
		List<Account> accountList = new ArrayList<>();
		String sql = "select id, password, info from account where user_id=?";
		Connection connection = DBUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		try {
			statement = connection.prepareStatement(sql);
			statement.setObject(1, userId);

			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				int id = resultSet.getInt("id");
				String password = resultSet.getString("password");
				String info = resultSet.getString("info");

				Account account = new Account();
				account.setId(id);
				account.setUserId(userId);
				account.setPassword(password);
				account.setInfo(info);

				accountList.add(account);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return accountList;
	}

	@Override
	public int getAccountTotalByUserId(int userId) {
		int taotal = 0;
		String sql = "select count(id) from account where user_id=?";
		Connection connection = DBUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		try {
			statement = connection.prepareStatement(sql);
			statement.setObject(1, userId);

			resultSet = statement.executeQuery();
			if (resultSet.next()) {
				taotal = resultSet.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return taotal;
	}

}
