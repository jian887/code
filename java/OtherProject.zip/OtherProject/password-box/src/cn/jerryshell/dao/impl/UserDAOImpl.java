package cn.jerryshell.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

import cn.jerryshell.dao.UserDAO;
import cn.jerryshell.entity.User;
import cn.jerryshell.util.DBUtil;

public class UserDAOImpl implements UserDAO {

	@Override
	public void addUser(User user) {
		String sql = "insert into user(username, password, email) value(?,?,?)";
		Connection connection = DBUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		try {
			statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			statement.setObject(1, user.getUsername());
			statement.setObject(2, user.getPassword());
			statement.setObject(3, user.getEmail());

			statement.executeUpdate();
			resultSet = statement.getGeneratedKeys();
			if (resultSet.next()) {
				user.setId(resultSet.getInt(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(connection, statement, resultSet);
		}
	}

	@Override
	public void updateUser(User user) {
		String sql = "update user set username=?, password=?, email=? where id=?";
		Connection connection = DBUtil.getConnection();
		PreparedStatement statement = null;
		try {
			statement = connection.prepareStatement(sql);
			statement.setObject(1, user.getUsername());
			statement.setObject(2, user.getPassword());
			statement.setObject(3, user.getEmail());
			statement.setObject(4, user.getId());

			statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(connection, statement, null);
		}
	}

	@Override
	public void deleteUser(int id) {
		String sql = "delete from user where id=?";
		Connection connection = DBUtil.getConnection();
		PreparedStatement statement = null;
		try {
			statement = connection.prepareStatement(sql);
			statement.setObject(1, id);

			statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(connection, statement, null);
		}
	}

	@Override
	public User getUserById(int id) {
		String sql = "select username, password, email from user where id=?";
		User user = null;
		Connection connection = DBUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		try {
			statement = connection.prepareStatement(sql);
			statement.setObject(1, id);

			resultSet = statement.executeQuery();
			if (resultSet.next()) {
				String username = resultSet.getString("username");
				String password = resultSet.getString("password");
				String email = resultSet.getString("email");

				user = new User();
				user.setId(id);
				user.setUsername(username);
				user.setPassword(password);
				user.setEmail(email);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(connection, statement, resultSet);
		}
		return user;
	}

	@Override
	public User getUserByUsernameAndPassword(String username, String password) {
		User user = null;
		String sql = "select id, email from user where username=? and password=?";
		Connection connection = DBUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		try {
			statement = connection.prepareStatement(sql);
			statement.setObject(1, username);
			statement.setObject(2, password);

			resultSet = statement.executeQuery();
			if (resultSet.next()) {
				int id = resultSet.getInt("id");
				String email = resultSet.getString("email");

				user = new User();
				user.setId(id);
				user.setUsername(username);
				user.setPassword(password);
				user.setEmail(email);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(connection, statement, resultSet);
		}
		return user;
	}

	@Override
	public List<User> list() {
		return list(0, Short.MAX_VALUE);
	}

	@Override
	public List<User> list(int start, int number) {
		List<User> userList = new LinkedList<>();
		String sql = "select id, username, password, email from user limit ?,?";
		Connection connection = DBUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		try {
			statement = connection.prepareStatement(sql);
			statement.setObject(1, start);
			statement.setObject(2, number);

			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				int id = resultSet.getInt("id");
				String username = resultSet.getString("username");
				String password = resultSet.getString("password");
				String email = resultSet.getString("email");

				User user = new User();
				user.setId(id);
				user.setUsername(username);
				user.setPassword(password);
				user.setEmail(email);

				userList.add(user);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(connection, statement, resultSet);
		}
		return userList;
	}

	@Override
	public int total() {
		int total = 0;
		String sql = "select count(id) from user";
		Connection connection = DBUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		try {
			statement = connection.prepareStatement(sql);

			resultSet = statement.executeQuery();
			if (resultSet.next()) {
				total = resultSet.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(connection, statement, resultSet);
		}
		return total;
	}

}
