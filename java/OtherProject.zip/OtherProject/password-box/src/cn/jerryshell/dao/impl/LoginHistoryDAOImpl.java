package cn.jerryshell.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import cn.jerryshell.dao.LoginHistoryDAO;
import cn.jerryshell.util.DBUtil;

public class LoginHistoryDAOImpl implements LoginHistoryDAO {

	@Override
	public void addLoginHistory(int userId, Date date) {
		String sql = "insert into login_history(user_id, login_date_time) value(?,?)";
		Timestamp timestamp = new Timestamp(date.getTime());
		Connection connection = DBUtil.getConnection();
		PreparedStatement statement = null;
		try {
			statement = connection.prepareStatement(sql);
			statement.setInt(1, userId);
			statement.setTimestamp(2, timestamp);

			statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(connection, statement, null);
		}
	}

	@Override
	public List<Date> getRecently2LoginDateTimeByUserId(int userId) {
		List<Date> dateList = new ArrayList<>();
		String sql = "select login_date_time from login_history where user_id=? order by id desc limit 2";
		Connection connection = DBUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		try {
			statement = connection.prepareStatement(sql);
			statement.setObject(1, userId);

			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				Timestamp timestamp = resultSet.getTimestamp("login_date_time");
				Date date = new Date(timestamp.getTime());
				dateList.add(date);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dateList;
	}

	@Override
	public int getLoginTotalNumberByUserId(int userId) {
		int total = 0;
		String sql = "select count(id) from login_history where user_id=?";
		Connection connection = DBUtil.getConnection();
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		try {
			statement = connection.prepareStatement(sql);
			statement.setObject(1, userId);

			resultSet = statement.executeQuery();
			if (resultSet.next()) {
				total = resultSet.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return total;
	}

}
