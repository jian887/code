package cn.jerryshell.service;

import java.util.Date;
import java.util.List;

public interface LoginHistoryService {

	/**
	 * 添加登录记录
	 * 
	 * @param userId
	 * @param date
	 */
	public void addLoginHistory(int userId, Date date);

	/**
	 * 添加登录记录
	 * 
	 * @param userId
	 */
	public void addLoginHistory(int userId);

	/**
	 * 根据用户 id 获取最近 2 次登录时间
	 * 
	 * @param userId
	 * @return
	 */
	public List<Date> getRecently2LoginDateTimeByUserId(int userId);

	/**
	 * 根据用户 id 获取登录次数
	 * 
	 * @param userId
	 * @return
	 */
	public int getLoginTotalNumberByUserId(int userId);
}
