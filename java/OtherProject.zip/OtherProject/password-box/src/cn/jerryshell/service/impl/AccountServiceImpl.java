package cn.jerryshell.service.impl;

import java.util.List;

import cn.jerryshell.dao.AccountDAO;
import cn.jerryshell.dao.impl.AccountDAOImpl;
import cn.jerryshell.entity.Account;
import cn.jerryshell.service.AccountService;

public class AccountServiceImpl implements AccountService {
	private AccountDAO accountDAO = new AccountDAOImpl();

	@Override
	public void addAccount(int userId, String password, String info) {
		Account account = new Account();
		account.setUserId(userId);
		account.setPassword(password);
		account.setInfo(info);

		accountDAO.addAccount(account);
	}

	@Override
	public void deleteAccount(int id) {
		accountDAO.deleteAccount(id);
	}

	@Override
	public void updateAccount(int id, int userId, String password, String info) {
		Account account = new Account();
		account.setId(id);
		account.setUserId(userId);
		account.setPassword(password);
		account.setInfo(info);

		accountDAO.updateAccount(account);
	}

	@Override
	public Account getAccountById(int id) {
		Account account = accountDAO.getAccountById(id);
		return account;
	}

	@Override
	public List<Account> getAccountListByUserId(int userId) {
		List<Account> accountList = accountDAO.getAccountListByUserId(userId);
		return accountList;
	}

}
