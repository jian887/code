package cn.jerryshell.service;

import java.util.List;

import cn.jerryshell.entity.Account;

public interface AccountService {

	/**
	 * 添加账号
	 * 
	 * @param userId
	 * @param password
	 * @param info
	 */
	public void addAccount(int userId, String password, String info);

	/**
	 * 删除账号
	 * 
	 * @param id
	 */
	public void deleteAccount(int id);

	/**
	 * 更新账号
	 * 
	 * @param id
	 * @param userId
	 * @param password
	 * @param info
	 */
	public void updateAccount(int id, int userId, String password, String info);

	/**
	 * 根据 id 获得账号
	 * 
	 * @param id
	 * @return
	 */
	public Account getAccountById(int id);

	/**
	 * 根据用户 id 获得账号列表
	 * 
	 * @param userId
	 * @return
	 */
	public List<Account> getAccountListByUserId(int userId);
}
