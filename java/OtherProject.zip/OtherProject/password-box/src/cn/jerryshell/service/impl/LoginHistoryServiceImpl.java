package cn.jerryshell.service.impl;

import java.util.Date;
import java.util.List;

import cn.jerryshell.dao.LoginHistoryDAO;
import cn.jerryshell.dao.impl.LoginHistoryDAOImpl;
import cn.jerryshell.service.LoginHistoryService;

public class LoginHistoryServiceImpl implements LoginHistoryService {
	private LoginHistoryDAO loginHistoryDAO = new LoginHistoryDAOImpl();

	@Override
	public void addLoginHistory(int userId, Date date) {
		loginHistoryDAO.addLoginHistory(userId, date);
	}

	@Override
	public void addLoginHistory(int userId) {
		loginHistoryDAO.addLoginHistory(userId, new Date());
	}

	@Override
	public List<Date> getRecently2LoginDateTimeByUserId(int userId) {
		List<Date> dateList = loginHistoryDAO.getRecently2LoginDateTimeByUserId(userId);
		return dateList;
	}

	@Override
	public int getLoginTotalNumberByUserId(int userId) {
		int total = loginHistoryDAO.getLoginTotalNumberByUserId(userId);
		return total;
	}

}
