package cn.jerryshell.entity;

import java.util.Date;

public class LoginHistory {

	private int id;
	private int userId;
	private Date loginDateTime;
	private Date lastLoginDateTime;
	private int loginTotalNumber;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public Date getLoginDateTime() {
		return loginDateTime;
	}

	public void setLoginDateTime(Date loginDateTime) {
		this.loginDateTime = loginDateTime;
	}

	public Date getLastLoginDateTime() {
		return lastLoginDateTime;
	}

	public void setLastLoginDateTime(Date lastLoginDateTime) {
		this.lastLoginDateTime = lastLoginDateTime;
	}

	public int getLoginTotalNumber() {
		return loginTotalNumber;
	}

	public void setLoginTotalNumber(int loginTotalNumber) {
		this.loginTotalNumber = loginTotalNumber;
	}
}
