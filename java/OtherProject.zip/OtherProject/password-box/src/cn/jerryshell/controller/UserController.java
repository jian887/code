package cn.jerryshell.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cn.jerryshell.entity.User;
import cn.jerryshell.service.LoginHistoryService;
import cn.jerryshell.service.UserService;
import cn.jerryshell.service.impl.LoginHistoryServiceImpl;
import cn.jerryshell.service.impl.UserServiceImpl;
import cn.jerryshell.util.Captcha;
import cn.jerryshell.util.ControllerUtil;

@WebServlet("/user")
public class UserController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private UserService userService = new UserServiceImpl();
	private LoginHistoryService loginHistoryService = new LoginHistoryServiceImpl();

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String path;
		String action = request.getParameter("action");
		if ("register".equals(action)) {
			path = register(request, response);
		} else if ("login".equals(action)) {
			path = login(request, response);
		} else if ("logout".equals(action)) {
			path = logout(request, response);
		} else {
			request.setAttribute("message", "未知操作");
			path = "message.jsp";
		}
		request.getRequestDispatcher(path).forward(request, response);
	}

	private String register(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String message;
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String password2 = request.getParameter("password2");
		String email = request.getParameter("email");
		String captchaStr = request.getParameter("captcha");
		Captcha captcha = (Captcha) request.getSession().getAttribute("captcha");
		if (ControllerUtil.isEmpty(username, password, password2, email, captchaStr)) {
			message = "字段不能为空";
		} else if (!captchaStr.equals(captcha.getCaptchaStr())) {
			message = "验证码错误";
		} else if (password.equals(password2)) {
			userService.register(username, password, email);
			message = "注册成功！";
		} else {
			message = "确认密码不一致";
		}
		request.setAttribute("message", message);
		return "message.jsp";
	}

	private String logout(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String message;
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		if (user == null) {
			message = "未登录，注销失败";
		} else {
			session.invalidate();
			message = "注销成功!";
		}
		request.setAttribute("message", message);
		return "message.jsp";
	}

	private String login(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String message;
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String captchaStr = request.getParameter("captcha");
		Captcha captcha = (Captcha) request.getSession().getAttribute("captcha");
		if (ControllerUtil.isEmpty(username, password)) {
			message = "字段不能为空";
		} else if (!captchaStr.equals(captcha.getCaptchaStr())) {
			message = "验证码错误";
		} else {
			User user = userService.login(username, password);
			if (user == null) {
				message = "用户名或密码错误";
			} else {
				HttpSession session = request.getSession();
				session.setAttribute("user", user);
				loginHistoryService.addLoginHistory(user.getId());
				message = "登录成功！";
			}
		}
		request.setAttribute("message", message);
		return "message.jsp";
	}

}
