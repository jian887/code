package cn.jerryshell.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cn.jerryshell.entity.Account;
import cn.jerryshell.entity.User;
import cn.jerryshell.service.AccountService;
import cn.jerryshell.service.impl.AccountServiceImpl;

@WebServlet("/account")
public class AccountController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private AccountService accountService = new AccountServiceImpl();

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String message = null;
		List<Account> accountList = null;
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		String action = request.getParameter("action");
		if ("list".equals(action)) {
			accountList = accountService.getAccountListByUserId(user.getId());
			request.setAttribute("accountList", accountList);
			request.getRequestDispatcher("account/accountList.jsp").forward(request, response);
			return;
		} else if ("addAccount".equals(action)) {
			String password = request.getParameter("password");
			String info = request.getParameter("info");
			accountService.addAccount(user.getId(), password, info);
			response.sendRedirect(request.getContextPath() + "/account?action=list");
			return;
		} else if ("deleteAccount".equals(action)) {
			String idStr = request.getParameter("id");
			int id = Integer.parseInt(idStr);
			accountService.deleteAccount(id);
			response.sendRedirect(request.getContextPath() + "/account?action=list");
			return;
		} else if ("updateAccountUI".equals(action)) {
			String idStr = request.getParameter("id");
			int id = Integer.parseInt(idStr);
			Account account = accountService.getAccountById(id);
			request.setAttribute("account", account);
			request.getRequestDispatcher("account/updateAccount.jsp").forward(request, response);
			return;
		} else if ("updateAccount".equals(action)) {
			String idStr = request.getParameter("id");
			int id = Integer.parseInt(idStr);
			String password = request.getParameter("password");
			String info = request.getParameter("info");
			accountService.updateAccount(id, user.getId(), password, info);
			response.sendRedirect(request.getContextPath() + "/account?action=list");
			return;
		} else {
			message = "未知操作";
		}
		request.setAttribute("message", message);
		request.getRequestDispatcher("message.jsp").forward(request, response);
	}

}
