package cn.jerryshell.util;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class DBUtil {

	private static String url;
	private static String username;
	private static String password;

	static {
		try {
			Class.forName("com.mysql.jdbc.Driver");

			Properties properties = new Properties();
			properties.load(DBUtil.class.getResourceAsStream("db.properties"));

			String dbms = properties.getProperty("dbms");
			String ip = properties.getProperty("ip");
			String port = properties.getProperty("port");
			String database = properties.getProperty("database");

			url = String.format("jdbc:%s://%s:%s/%s", dbms, ip, port, database);
			username = properties.getProperty("username");
			password = properties.getProperty("password");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static Connection getConnection() {
		Connection conn = null;
		try {
			conn = DriverManager.getConnection(url, username, password);
		} catch (SQLException e) {
			e.printStackTrace();
			if (conn == null) {
				throw new RuntimeException("conn == null 与数据库建立连接失败");
			}
		}
		return conn;
	}

	public static void close(Connection connection, Statement statement, ResultSet resultSet) {
		try {
			if (resultSet != null) {
				resultSet.close();
			}
			if (statement != null) {
				statement.close();
			}
			if (connection != null) {
				connection.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
