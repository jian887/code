package cn.jerryshell.util;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.Random;

public class GenerateCaptcha {
	private static final int HEIGHT = 25;
	private static final int WIDTH = 120;
	private static final int RANDOM_STR_LEN = 4;

	private static void drawBackground(Graphics graphics) {
		graphics.setColor(Color.WHITE);
		graphics.fillRect(0, 0, WIDTH, HEIGHT);
	}

	private static void drawFont(Graphics graphics, String randomStr) {
		graphics.setColor(Color.BLACK);
		graphics.setFont(new Font("宋体", Font.BOLD, 26));
		graphics.drawString(randomStr, 20, 20);
	}

	private static void drawLine(Graphics graphics) {
		graphics.setColor(Color.GREEN);
		for (int i = 0; i < 4; i++) {
			int startX = (int) (Math.random() * WIDTH);
			int endX = (int) (Math.random() * WIDTH);
			int startY = (int) (Math.random() * HEIGHT);
			int endY = (int) (Math.random() * HEIGHT);
			graphics.drawLine(startX, startY, endX, endY);
		}
	}

	/**
	 * 生成 Captcha 并返回
	 * 
	 * @return
	 */
	public static Captcha generateCaptcha() {
		String randomStr = GenerateCaptcha.generateRandomStr();
		BufferedImage bufferedImage = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_RGB);
		Graphics graphics = bufferedImage.getGraphics();
		drawBackground(graphics);
		drawLine(graphics);
		drawFont(graphics, randomStr);
		return new Captcha(randomStr, bufferedImage);
	}

	/**
	 * 生成一串长度为 4 的字符串，并返回
	 * 
	 * @return
	 */
	public static String generateRandomStr() {
		String str = "abcdefghijklmnopqrstuvwxyz1234567890";
		StringBuilder stringBuilder = new StringBuilder();
		Random random = new Random();
		for (int i = 0; i < RANDOM_STR_LEN; i++) {
			int randomInt = Math.abs(random.nextInt() % str.length());
			stringBuilder.append(str.substring(randomInt, randomInt + 1));
		}
		return stringBuilder.toString();
	}
}
