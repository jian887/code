package cn.jerryshell.util;

public class ControllerUtil {

	public static boolean isEmpty(String... strs) {
		for (int i = 0, len = strs.length; i < len; i++) {
			String str = strs[i].trim();
			if (str.isEmpty()) {
				return true;
			}
		}
		return false;
	}
}
