package cn.jerryshell.util;

import java.awt.image.BufferedImage;

public class Captcha {
	private BufferedImage captchaImage;
	private String captchaStr;

	public Captcha(String captchaStr, BufferedImage captchaImage) {
		this.captchaStr = captchaStr;
		this.captchaImage = captchaImage;
	}

	public BufferedImage getCaptchaImage() {
		return captchaImage;
	}

	public String getCaptchaStr() {
		return captchaStr;
	}

	public void setCaptchaImage(BufferedImage captchaImage) {
		this.captchaImage = captchaImage;
	}

	public void setCaptchaStr(String captchaStr) {
		this.captchaStr = captchaStr;
	}
}
