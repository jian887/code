## 进度

### v2.0
- [ ] 使用 Bootstrap 美化界面
- [x] 验证码功能

### v1.0
- [x] UserDAO
- [x] UserService
- [x] UserController
- [x] UserJSP
- [x] AccountDAO
- [x] AccountService
- [x] AccountController
- [x] AccountJSP
- [x] LoginHistoryDAO
- [x] LoginHistoryService
- [x] EncodeFilter
- [x] AccountFilter