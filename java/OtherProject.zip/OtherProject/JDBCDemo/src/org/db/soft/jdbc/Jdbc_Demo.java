package org.db.soft.jdbc;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


public class Jdbc_Demo {
	public static void main(String[] args) {
		//1.加载驱动
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("驱动路径不正确");
		}
		//2.通过jdk提供的驱动管理工具（DriverManager）连接指定数据库
		String url="jdbc:mysql://localhost:3307/school";
		String user="root";
		String password="123456";
		try {
			Connection connection=DriverManager.getConnection(url, user, password);
			if(!connection.isClosed()){
				System.out.println("open");
			}else{
				System.out.println("closed");
			}
			//3.通过数据库连接创建数据库声明 
			Statement statement=connection.createStatement();

			String sql="update human set humanName='eu' where humanName='e'";
			int rowChanged=statement.executeUpdate(sql);
			if(rowChanged>0){
				System.out.println("update database success");
			}else{
				System.out.println("update database unsuccess");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

}
