package org.db.soft.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Demo1 {

	public static void main(String[] args) {
		try {
			//加载数据库驱动
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		String url = "jdbc:mysql://localhost:3307/school";
		String user = "root";
		String password = "123456";
		Connection con = null;
		
		try {
			//创建数据库连接
			con = DriverManager.getConnection(url, user, password);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
//		String sql = "insert into person (personName) value (?)";
//		PreparedStatement pstmt = null;
//		try {
//			//通过数据库连接创建数据库声明
//			 pstmt = con.prepareStatement(sql);
//			 pstmt.setObject(1, "lao wang");
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
		
//		String sql = "update person set personName = ?  where personId = ?";
//		PreparedStatement pstmt = null;
//		try {
//			//通过数据库连接创建数据库声明
//			 pstmt = con.prepareStatement(sql);
//			 pstmt.setObject(1, "Will.Smith");
//			 pstmt.setObject(2, 5);
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
		
		String sql = "update human set humanName='l' where humanName='s'";
		PreparedStatement pstmt = null;
		try {
			//通过数据库连接创建数据库声明
			 pstmt = con.prepareStatement(sql);
			 pstmt.setObject(1, 5);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		int row = 0;
		try {
			 //通过数据库声明执行SQL语句 ， insert update delete都使用executeUpdate()
			 row = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		if(row > 0) {
			System.out.println("success");
		}else {
			System.out.println("fail");
		}
		
		
		try {
			//关闭数据相关连接
			pstmt.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
}












