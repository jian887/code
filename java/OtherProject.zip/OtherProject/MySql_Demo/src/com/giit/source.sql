select * from class;

insert
into class
values('16513005','2015-10-20',35);

update class
set class_count=38
where class_no='16513002';

alter table class
add  primary key(class_no) ;

select *
from class
where class_count>35&&class_start>'2015-12-31';

create index classsum on class(class_count);

create view conview
as 
select class_no
from class;

select *
from conview;

drop view conview;

delete 
from conview 
where class_no='16513005';

select version;

describe class;

