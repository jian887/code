create table human
(
	humanId int primary key auto_increment,
	humanName varchar(20),
	humanSex varchar(10),
	humanEmail varchar(50)
);
