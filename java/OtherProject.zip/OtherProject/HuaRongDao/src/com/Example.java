package com;

public class Example {
	public static void main(String[] args) {
		new Hua_Rong_Road();
	}

}
